export default {
	plugins: {
		autoprefixer: {},
	},
};

